<header id="header" class="logoSeparator smartScrollDown">
   <div class="menuFixedWrap" style="height: auto;">
      <a href="#" class="openMobileMenu"></a>
      <a href="#" class="openTopMenu"></a>
    
      <div class="wrapTopMenu">
         <div class="topMenu main">
            <ul id="mainmenu" class="sf-js-enabled">
               <li class="menu-item current-menu-ancestor current-menu-parent menu-item-has-children">
                  <a href="index.php">Home</a>
                  
               </li>
               <li class="menu-item ">
                  <a href="our_story.php">Our Story</a>
                  
               </li>
               <li class="menu-item">
                  <a href="index.php#cardano">Cardano Blockchain</a>
                  
               </li>
              
            </ul>
            <ul id="mainmenu_right" class="sf-js-enabled">
            <li class="menu-item ">
                  <a href="our_wine.php">Our Wines</a>
               </li>
               <li class="menu-item"><a href="index.php#media">Media</a></li>
               <li class="menu-item ">
                  <a href="gallery.php">Gallery</a>
               </li>
               <li class="menu-item"><a href="contacts.php">Contact</a></li>
            </ul>
         </div>
      </div>
   </div>
   <div class="logoWrap">
      <div class="logoHeader">
         <a href="index.php">
         <span class="logoImg">
         <img src="images/logo.png" alt="">
         </span>
         </a>
         <span class="logo_bg_size"></span>
      </div>
  
   </div>
</header>